//
//  Location.swift
//  LogMyRun
//

import Foundation
import CoreData

@objc(Location)
class Location: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
